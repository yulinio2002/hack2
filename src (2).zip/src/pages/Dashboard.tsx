import React, { useState, useEffect } from 'react'
import { useExpensesSummary, useDeleteExpense, useCreateExpense } from '../hooks/useExpensesSummary'
import type { ExpenseSummary } from '../types/expenseSummary'
import Modal from '../components/Modal'
import Card from '../components/Card'
import ExpenseForm from '../components/ExpenseForm'

const Dashboard: React.FC = () => {
  
  const { data, isLoading, isError, refetch } = useExpensesSummary()
  const deleteExpenseMutation = useDeleteExpense() 
  const createExpenseMutation = useCreateExpense()
  const _summaries: ExpenseSummary[] = data?.data ?? [] 
  const [summaries, setSummaries] = useState<ExpenseSummary[]>(_summaries)
  const [isModalOpen, setIsModalOpen] = useState(false)

  // Actualizar el estado local cuando cambien los datos del servidor
  useEffect(() => {
    setSummaries(_summaries)
    console.log("_sum", _summaries)
    console.log("summaries", _summaries) // Usar _summaries aquí ya que summaries aún no se ha actualizado
  }, [_summaries]) // Dependencia en _summaries, no array vacío

  async function deleteFunction(id: number) {
    const confirmDelete = window.confirm('¿Estás seguro de eliminar este resumen?')
    if (!confirmDelete) return
    
    try {
      await deleteExpenseMutation.mutateAsync(id)
      
      // Refrescar los datos del servidor
      await refetch()
    } catch (error) {
      console.error('Error al eliminar:', error)
    }
  }

  if (isLoading) {
    return <div className="p-4">Cargando resumen...</div>
  }

  if (isError) {
    return <div className="p-4 text-red-500">Error al cargar el resumen.</div>
  }

const handleCreateExpense = async (formData: any) => {
    try {
      await createExpenseMutation.mutateAsync(formData)
      setIsModalOpen(false) // Cerrar modal después de crear
      console.log('Gasto creado correctamente')
    } catch (error) {
      console.error('Error al crear gasto:', error)
      throw error // Re-lanzar para que el formulario pueda manejarlo
    }
  }

  const openModal = () => {
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setIsModalOpen(false)
  }


   return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Resumen de Gastos</h1>
        <button 
          onClick={openModal}
          className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-medium transition-colors"
        >
          + Agregar Gasto
        </button>
      </div>

      {deleteExpenseMutation.isPending && (
        <div className="mb-4 p-2 bg-yellow-100 text-yellow-800 rounded">
          Eliminando...
        </div>
      )}
      
      {summaries.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {summaries.map(item => (
            <Card 
              key={item.id} 
              item={item} 
              deleteFunction={deleteFunction}
            />
          ))}
        </div>
      ) : (
        <div className="text-center text-gray-500 py-8">
          <p className="text-lg mb-2">No hay gastos registrados</p>
          <p className="text-sm">¡Comienza agregando tu primer gasto!</p>
        </div>
      )}

      <Modal 
        isOpen={isModalOpen} 
        onClose={closeModal} 
        title="Agregar Nuevo Gasto"
      >
        <ExpenseForm 
          onSubmit={handleCreateExpense}
          onCancel={closeModal}
          isLoading={createExpenseMutation.isPending}
        />
      </Modal>
    </div>
  )
}

export default Dashboard