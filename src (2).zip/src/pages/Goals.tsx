import React from 'react'
export default function PLACEHOLDER() {
  return <div className="p-4 text-center">Página </div>
}