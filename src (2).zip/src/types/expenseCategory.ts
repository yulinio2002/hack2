
export interface ExpenseCategory {
  id: number
  name: string
}