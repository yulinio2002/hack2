export const formatCurrency = (value: number) =>
  '$' + value.toFixed(2)